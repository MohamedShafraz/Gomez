<?php
    //App root
    define("APPROOT",dirname(dirname(__FILE__)));
    //URL root
    define("URLROOT",'http://localhost/gomez/');
    //Website name
    define('SITENAME', 'Gomez');
    //Host name
    define('Hostname','localhost');
    //User name
    define('Username','root');
    //Password
    define('Password','');
    //Database name
    define('Dbname', 'gomez_hc');
    
?>