<?php 

class DoctorControls extends Controller{

    public function __construct(){
        
    }

    public function index(){
        $this->view('/Doctor/doctor_view');
    }

    public function viewabout(){
        $this->view('doctor_view');
    }

    public function viewdailyappointments(){
        $this->view('/Doctor/doctor_appointments');
    }

}
?>