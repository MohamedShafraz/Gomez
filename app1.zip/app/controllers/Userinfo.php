<?php
class Userinfo extends Controller{
    public function index(){
        $this->view("Admin/Userinformation_view");
    }
}
?>