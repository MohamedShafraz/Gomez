<?php 
    class DoctorModel {
        private $db;

        public function __construct($database) {
            $this->db = $database;
        }

    }

?>