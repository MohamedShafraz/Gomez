<?php 

    echo "Doctor View";
    echo "SAJINI";
?>