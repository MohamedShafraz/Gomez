<?php

class DoctorController extends Controller {
    public function index() {
        if(!isset($_SESSION)){
            session_start();}
            
        $this->view('Doctor/dashboard_view');
    }

    public function ViewAppointment() {
        $this->view('Doctor/appointment_view');
    }

    public function ViewPrescription() {
        $this->view('Doctor/prescription_view');
    }

    public function ViewReminder() {
        $this->view('Doctor/reminder_view');
    }

    public function ViewProfile(){
        if(!isset($_SESSION)){
            session_start();}
        $user = $_SESSION["USER"];
        var_dump($user);
        if ($user["usertype"] == "Doctor"){
            $this->view('Doctor/profile_view' ,[ "user" => $user]);
        }
        else {
            header("Location: ".URLROOT."/Users/login"); 
            exit(); 
        }
    }





























































































}
     















?>