<?php require_once(APPROOT."/views/Doctor/navbar_view.php");?>
<aside class="sidenav">
    <ul>
        <img src="<?=URLROOT."/resources/user.png"?>" ><br><br>
        <li><a href="<?=URLROOT."/DoctorController"?>">Dashboard</a></li>
        <li><a href="<?=URLROOT."/DoctorController/ViewAppointment/"?>">Appointment</a></li>
        <li><a href="<?=URLROOT."/DoctorController/ViewPrescription"?>">Prescription</a></li>
        <li><a href="<?=URLROOT."/DoctorController/ViewReminder"?>">Reminder</a></li>
    </ul>

    <style>
    ul {
        list-style: none;
        padding: 0;
        margin: 0;
    }

    ul li a {
        text-decoration: none;
        color: inherit;
    }


        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            background-color: #f4f4f4;
        }

        .profile-container {
            max-width: 800px;
            margin: 20px auto;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
            border-radius: 10px;
            overflow: hidden;
        }

        .profile-picture {
            width: 100%;
            text-align: center;
        }

        .profile-picture img {
            max-width: 100%;
            height: auto;
            border-radius: 50%;
        }

        .profile-details {
            padding: 20px 0;
        }

        .profile-details h2 {
            color: #333;
        }

        .profile-details p {
            color: #666;
        }

        @media (max-width: 600px) {
            .profile-container {
                padding: 10px;
            }
        }
    
</style>



</aside>
<article class="dashboard">
    <div style="margin-left:24%;">
    <h1 style="text-align: center;">Profile View</h1>
    

<div class="profile-container">
        <div class="profile-details">
            <h2><?php echo $data["user"]["Username"];?></h2>
            <p>Email: <?php echo $data["user"]["Email"];?></p>
            <p>Address: <?php echo $data["user"]["Address"];?></p>
            <p>Occupation: Developer</p>
            <!-- Add more profile data as needed -->
        </div>
    </div>
        
    
    </div>
</div>
</div>
</article>

<?php require_once(APPROOT."/views/Admin/footer_view.php");?>